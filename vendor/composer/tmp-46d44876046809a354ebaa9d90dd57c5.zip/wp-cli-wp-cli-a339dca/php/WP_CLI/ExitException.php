<?php

namespace WP_CLI;

use Exception;

class ExitException extends Exception {}
