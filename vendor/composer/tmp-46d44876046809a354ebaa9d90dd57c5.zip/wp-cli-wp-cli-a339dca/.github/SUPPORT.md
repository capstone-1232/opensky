Support
=======

Hi there,

GitHub issues are meant for enhancement requests and specific, reproducible bugs, not for general support questions. For support options, please review https://wp-cli.org/#support
